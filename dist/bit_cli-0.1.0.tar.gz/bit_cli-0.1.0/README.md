# bit

`bit` is a Python CLI that translates natural-language shell instructions into Linux shell commands by calling a locally running OLLAMA model.

Example:

```bash
$ bit create folder new_folder
mkdir new_folder
```

When `bit` is run from an interactive terminal that permits tty injection, it attempts to preload the generated command into the next shell prompt instead of only printing it. In non-interactive contexts, or when tty injection is unavailable, it falls back to stdout.

## Features

- Translates free-form instructions into one shell command.
- Stores configuration in `~/.bit` using TOML.
- Supports interactive model selection with `bit --setup`.
- Exposes shell integration instructions for Bash and Zsh so generated commands can be inserted into the prompt buffer.
- Builds as a standard Python package with `python -m build`.

## Requirements

- Python 3.11 or newer.
- A local OLLAMA installation.
- An OLLAMA server available at `http://127.0.0.1:11434`.
- At least one installed OLLAMA model.

## Installation

Build and install locally:

```bash
python -m build
python -m pip install dist/bit_cli-0.1.0-py3-none-any.whl
```

Or install in editable mode while developing:

```bash
python -m pip install -e .
```

After installation, the `bit` command is available directly on the command line.

## Initial Setup

Run:

```bash
bit --setup
```

This command:

1. Queries the local OLLAMA instance for installed models.
2. Displays them as a numbered list.
3. Prompts you to select one.
4. Saves the result in `~/.bit`.

The config file is TOML and looks like this:

```toml
model = "llama3.1:8b"
host = "http://127.0.0.1:11434"
```

## Usage

Translate an instruction:

```bash
bit create folder new_folder
bit find large log files in current directory
bit show disk usage for home directory
```

Force plain stdout output even in an interactive shell:

```bash
bit --print-only create folder new_folder
```

Print Bash integration helper:

```bash
bit --print-shell-integration bash
```

Print Zsh integration helper:

```bash
bit --print-shell-integration zsh
```

Show help:

```bash
bit --help
```

## Shell Integration

In a regular interactive terminal session, `bit` now tries to inject the generated command into the next prompt buffer directly. That depends on tty support for `TIOCSTI`, which may be unavailable or disabled on some systems. For environments where that mechanism is blocked, shell integration is also available through Bash and Zsh widgets.

To enable that widget in Bash:

```bash
source <(bit --print-shell-integration bash)
```

To enable that widget in Zsh:

```bash
source <(bit --print-shell-integration zsh)
```

Then type a natural-language instruction directly at the shell prompt and press `Ctrl-x Ctrl-b`. The widget will:

1. Read the current command line buffer as the instruction.
2. Call the installed `bit` CLI.
3. Replace the current command line with the generated shell command.

Nothing is executed automatically. You can edit the generated command and then press Enter yourself.

To load this automatically, add the matching `source <(bit --print-shell-integration ...)` line to your shell startup file.

## Build

Create a source distribution and wheel:

```bash
python -m build
```

## Limitations and Security Notes

- The tool asks the model for a single shell command, but model output is still untrusted text.
- `bit` rejects obvious malformed multi-line and fenced responses, but it does not prove a generated command is safe.
- Review generated commands before executing them.
- Direct prompt insertion relies on terminal input injection support and may be blocked by system policy.
- If direct insertion is unavailable, use the Bash integration helper or `--print-only`.
- The default target is Linux shell syntax even if the tool is run elsewhere.